package com.praktikum.tugassatu;

import android.os.Bundle;

public interface halamankedua {
    void onCreate(Bundle savedInstanceState);
}
